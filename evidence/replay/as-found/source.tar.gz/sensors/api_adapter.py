"""Live API sensor adapter (Open-Meteo).

Fetches real current weather and air-quality data for all 20 node coordinates
from the free, no-key Open-Meteo API. This is the honest "real data" path: it
uses genuine live readings, labels them ``source="api"``, and marks any
derived value (e.g. water level inferred from precipitation) as
``quality_flag="estimated"``.

If the network is unavailable or the request fails, the adapter raises
``ApiUnavailable`` so the launcher can warn the user and fall back to
simulation — it never silently invents data and calls it live.
"""

from __future__ import annotations

import http.client
import json
import math
from datetime import datetime
import urllib.error
import urllib.parse
import urllib.request

from config.nodes import NODES
from sensors.base import SensorAdapter, make_reading
from simulation.engine import _heat_index, _wind_chill

OPEN_METEO_FORECAST = "https://api.open-meteo.com/v1/forecast"
OPEN_METEO_AIR = "https://air-quality-api.open-meteo.com/v1/air-quality"

# Per-environment sensitivity converting rain fallen since local midnight
# (mm) to a water-level proxy (m). River nodes respond most; urban least.
_PRECIP_SENSITIVITY = {
    "river": 0.15, "park": 0.08, "residential": 0.07, "school": 0.06, "urban": 0.05,
}
_BASE_WATER = {
    "river": 1.0, "park": 0.35, "residential": 0.30, "school": 0.25, "urban": 0.20,
}


def _water_level_proxy(environment: str, rain_since_midnight: float) -> float:
    """Estimated metres from rain fallen since local midnight, never a gauge depth."""
    return _BASE_WATER[environment] + _PRECIP_SENSITIVITY[environment] * rain_since_midnight


class ApiUnavailable(RuntimeError):
    """Raised when live API data cannot be fetched (offline, rate-limited, etc.)."""


def _http_get_json(url: str, params: dict, timeout: float = 8.0) -> dict:
    query = urllib.parse.urlencode(params)
    full = f"{url}?{query}"
    try:
        with urllib.request.urlopen(full, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, OSError, ValueError,
            http.client.HTTPException) as e:
        # URLError covers HTTPError; ValueError covers a non-JSON body (a
        # captive-portal login page on school Wi-Fi, a proxy block page) and
        # bad UTF-8; HTTPException covers a truncated/malformed response.
        raise ApiUnavailable(str(e)) from e


def _eu_aqi_to_us_scale(eu_aqi: float | None) -> float:
    """Open-Meteo returns a European AQI (0-100+). Map onto the 0-500 scale the
    rest of the system uses so the risk engine thresholds stay consistent."""
    if eu_aqi is None:
        return 50.0
    return max(0.0, min(500.0, eu_aqi * 2.5))


class ApiAdapter(SensorAdapter):
    """Live Open-Meteo data for every node. Falls back via ``ApiUnavailable``."""

    source = "api"

    def __init__(self, timeout: float = 8.0):
        self.timeout = timeout

    def _fetch_batch(self, urls_params):
        return [_http_get_json(u, p, self.timeout) for u, p in urls_params]

    def read_all(self, scenario: str = "none", tick: float = 0.0) -> list[dict]:
        lats = ",".join(str(n["latitude"]) for n in NODES)
        lons = ",".join(str(n["longitude"]) for n in NODES)

        weather = _http_get_json(OPEN_METEO_FORECAST, {
            "latitude": lats, "longitude": lons,
            "current": "temperature_2m,relative_humidity_2m,wind_speed_10m,"
                       "pressure_msl,apparent_temperature",
            "hourly": "precipitation",
            # Request m/s explicitly — Open-Meteo defaults to km/h, which the
            # risk engine would otherwise misread as gale-force wind.
            "wind_speed_unit": "ms",
            "timezone": "auto", "forecast_days": 1,
        }, self.timeout)
        air = _http_get_json(OPEN_METEO_AIR, {
            "latitude": lats, "longitude": lons,
            "current": "european_aqi", "timezone": "auto",
        }, self.timeout)

        # Open-Meteo returns a list (one element per coordinate) when multiple
        # coordinates are requested; normalise to a list either way.
        weather_list = weather if isinstance(weather, list) else [weather]
        air_list = air if isinstance(air, list) else [air]
        if not weather_list or not air_list:
            raise ApiUnavailable("live response contained no locations")
        # Every node must get its OWN location's data. Padding a short
        # response with another location's values and stamping it "api"
        # would be invented live data, so a short response is unavailable.
        if len(weather_list) != len(NODES) or len(air_list) != len(NODES):
            raise ApiUnavailable(
                f"live response returned {len(weather_list)} weather / "
                f"{len(air_list)} air-quality locations for {len(NODES)} nodes")

        readings = []
        for idx, node in enumerate(NODES):
            w = weather_list[idx]
            a = air_list[idx]
            cur = w.get("current", {})
            # A live reading must come from the response. A placeholder here
            # would be stamped source="api" and shown behind a "Live API"
            # badge, so a payload without usable values is reported as
            # unavailable and the caller falls back to labelled simulation.
            temp = cur.get("temperature_2m")
            humidity = cur.get("relative_humidity_2m")
            wind = cur.get("wind_speed_10m")
            pressure = cur.get("pressure_msl")
            if temp is None or humidity is None or wind is None or pressure is None:
                raise ApiUnavailable(
                    f"live response has no usable current values for "
                    f"{node['node_id']}")
            apparent = cur.get("apparent_temperature", temp)

            # The API's current and hourly times use the same requested local
            # timezone. Never include rain from forecast hours later today.
            try:
                current = datetime.fromisoformat(cur["time"]).replace(minute=0, second=0, microsecond=0)
                hourly = w["hourly"]
                pairs = list(zip(hourly["time"], hourly["precipitation"], strict=True))
                elapsed = [(datetime.fromisoformat(t), value) for t, value in pairs
                           if t[:10] == cur["time"][:10]
                           and datetime.fromisoformat(t) <= current]
                if len(elapsed) != current.hour + 1 or any(
                        value is None or not math.isfinite(float(value)) for _, value in elapsed):
                    raise ValueError("incomplete elapsed hourly precipitation")
                precip = sum(float(value) for _, value in elapsed)
            except (KeyError, TypeError, ValueError) as exc:
                raise ApiUnavailable(
                    f"live response has no usable elapsed rainfall for {node['node_id']}") from exc

            env = node["environment"]
            water = _water_level_proxy(env, precip)
            aqi = _eu_aqi_to_us_scale(a.get("current", {}).get("european_aqi"))

            # Prefer Open-Meteo's apparent temperature; derive locally if absent.
            if apparent is None:
                wind_chill = _wind_chill(temp, wind)
                heat_index = _heat_index(temp, humidity)
            else:
                wind_chill = min(apparent, temp) if temp < 12 else temp
                heat_index = max(apparent, temp) if temp >= 26 else temp

            readings.append(make_reading(
                node,
                temperature=temp,
                humidity=humidity,
                air_quality=aqi,
                water_level=water,
                wind_speed=wind,
                wind_chill=wind_chill,
                heat_index=heat_index,
                barometric_pressure=pressure,
                source="api",
                # Water level is a precipitation-derived proxy, not a measured value.
                quality_flag="estimated",
                # API values are live and UNMODIFIED — scenario deltas are only
                # applied in simulation/demo modes (simulation/engine.py). Stamp
                # "observed" so an api reading never falsely claims a scenario
                # delta was applied to its values.
                scenario="observed",
            ))
        return readings
